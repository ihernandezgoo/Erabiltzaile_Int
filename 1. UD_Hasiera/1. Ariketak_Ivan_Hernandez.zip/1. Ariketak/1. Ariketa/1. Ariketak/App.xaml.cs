﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace _1._Ariketak
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
